// You may change this file as per your need
window.pramukhime_lang = window.pramukhime_lang || {};
pramukhime_lang['pramukhime'] = {'english': 'English'};
pramukhime_lang['pramukhindic'] = {
assamese: 'Assamese',
bengali: 'Bengali',
bodo: 'Bodo',
dogri: 'Dogri',
gujarati: 'Gujarati',
hindi: 'Hindi',
kannada: 'Kannada',
kashmiri: 'Kashmiri',
konkani: 'Konkani',
maithili: 'Maithili', 
malayalam:'Malayalam',
manipuri: 'Manipuri',
marathi: 'Marathi',
marathimodi: 'Marathi (Modi)',
meitei: 'Meitei',
nepali: 'Nepali',
odia: 'Odia',
punjabi: 'Punjabi',
sanskrit: 'Sanskrit',
santali: 'Santali',
sindhi: 'Sindhi',
sora: 'Sora',
tamil: 'Tamil', 
telugu: 'Telugu',
english:'English',
readableenglish:'Readable English'
};